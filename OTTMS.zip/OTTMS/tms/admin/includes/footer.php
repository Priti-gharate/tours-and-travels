<div class="copyrights">
	 <p>© 2023 TANDT. All Rights Reserved |  <a href="#">TMS</a> </p>
</div>	
