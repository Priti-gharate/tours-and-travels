<?php 
$conn=mysqli_connect('localhost','root','','tms');
if(!empty($conn)){
    echo "connection success";

}else{
    echo"connection error";
}


?>